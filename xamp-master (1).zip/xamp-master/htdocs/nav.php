<nav>
			<ul>
				<li><a href="index.php">Start</a></li>
				<li><a href="products.php">Produkter</a></li>
				<li><a href="sida3.php">Varusida 2</a></li>
				<li><a href="login.php">Logga in</a></li>
			</ul>
		</nav>